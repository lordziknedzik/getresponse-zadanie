import React, {ReactElement} from 'react'

const UnderConstruction = ():ReactElement => {

    return (
        <div className='underconstuction'>
          Strona w budowie lub strona niedostępna. Przepraszamy.
        </div>
    )
}

export default UnderConstruction;