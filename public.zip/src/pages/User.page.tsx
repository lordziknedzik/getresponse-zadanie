import React, {ReactElement} from 'react'

const User = ():ReactElement => {

    return (
        <div className='user'>
User
        </div>
    )
}

export default User;